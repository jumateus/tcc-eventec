package com.example.eventec

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
